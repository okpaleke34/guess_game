// integration.test.js
const request = require('supertest');
const { app } = require('../app'); // Adjust the path based on your project structure
const { expect } = require('chai');
const { genID } = require('../app/helpers/functions');

describe('Integration Tests for Oracle to Human Game Routes', () => {
    
});
